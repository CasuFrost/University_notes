#!/bin/sh
make clean test_results.html
