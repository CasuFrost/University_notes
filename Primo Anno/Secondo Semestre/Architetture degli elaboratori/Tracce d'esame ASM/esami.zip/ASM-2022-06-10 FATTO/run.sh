#!/bin/sh
make test_results.html
